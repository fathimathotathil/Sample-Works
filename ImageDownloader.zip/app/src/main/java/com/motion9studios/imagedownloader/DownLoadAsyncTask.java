package com.motion9studios.imagedownloader;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.net.Uri;
import android.util.Log;


/**
 * This class allows to download image using AsyncTask
 */
public class DownLoadAsyncTask extends AsyncTask<Uri,Integer,Uri> {

    /**
     * Object of Activity
     */
    private Activity activity;

    /**
     * TAG for Logging purposes
     */
    private final String TAG = getClass().getSimpleName();

    /**
     * OnTaskCompleted interface object. OnTaskCompleted interface allows communication between
     * Download AsyncTask and Main Activity. Communication required in two instances
     * 1. When image downloaded successfully and to begin another AsyncTask to filter the downloaded
     * image
     * 2. When downloading is cancelled due to various reasons
     */
    private OnTaskCompleted onTaskCompleted =null;


    public DownLoadAsyncTask(Activity activity, OnTaskCompleted onTaskCompleted) {
        onAttach(activity);
        this.onTaskCompleted = onTaskCompleted;
    }

    @Override
    protected Uri doInBackground(Uri... url) {

        Log.d(TAG, "doInBackground method");

        // Call Util method to download image
        Uri uri = Utils.downloadImage(activity.getApplicationContext(),url[0]);

        //If image could not be downloaded, uri will be null and the
        //process cancelled and the hook method onCancelled is called
        if(uri == null){
            cancel(true);
            Log.d(TAG,"No image");
        }

        return uri;

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        Log.d(TAG, "onPreExecute method");
    }

    @Override
    protected void onPostExecute(Uri uri) {
        super.onPostExecute(uri);

        Log.d(TAG,"onPostExecute method");
        // If image downloaded successfully
        if(uri!=null){


            //Communicated back to MainActivity through OnTaskCompleted interface
            onTaskCompleted.onTaskCompleted(uri);
        }




    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        Log.d(TAG,"onProgressUpdate method");
    }

    @Override
    protected void onCancelled(Uri uri) {
        super.onCancelled(uri);
        //if downloading is interrupted
        onTaskCompleted.onTaskCancelled(uri);
        Log.d(TAG,"onCancelled method");
    }

    public void onAttach(Activity activity){

        this.activity = activity;
        Log.d(TAG,"onAttach method");
    }

    public void onDetach(){

        this.activity = null;
        Log.d(TAG,"onDetach method");
    }
}
