package com.motion9studios.imagedownloader;

import android.app.Activity;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

/**
 * This class allows to filter image using AsyncTask
 */
public class FilterAsyncTask extends AsyncTask<Uri,Integer,Uri> {

    private Activity activity;
    private final String TAG = getClass().getSimpleName();
    private OnTaskCompleted onTaskCompleted =null;


    public FilterAsyncTask(Activity activity, OnTaskCompleted onTaskCompleted) {
        onAttach(activity);
        this.onTaskCompleted = onTaskCompleted;
    }

    @Override
    protected Uri doInBackground(Uri... uri) {

        Log.d(TAG, "doInBackground method");

        // Call Util method to filter image
        Uri filteredImageUri = Utils.grayScaleFilter(activity.getApplicationContext(),uri[0]);

        //If image could not be filtered, filteredImageUri will be null and the
        //process cancelled and the hook method onCancelled is called

        if(filteredImageUri == null){
            cancel(true);
            Log.d(TAG,"No image");
        }

        return filteredImageUri;


    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        Log.d(TAG, "onPreExecute method");
    }

    @Override
    protected void onPostExecute(Uri uri) {
        super.onPostExecute(uri);
        Log.d(TAG,"onPostExecute method");
        // If image filtered successfully
        if(uri!=null){

            //Communicated back to MainActivity through OnTaskCompleted interface
            onTaskCompleted.onTaskCompleted(uri);
        }



    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        Log.d(TAG,"onProgressUpdate method");
    }

    @Override
    protected void onCancelled(Uri uri) {
        super.onCancelled(uri);
        //if filtering is interrupted
        onTaskCompleted.onTaskCancelled(uri);
        Log.d(TAG,"onCancelled method");
    }

    public void onAttach(Activity activity){

        this.activity = activity;
        Log.d(TAG,"onAttach method");
    }

    public void onDetach(){

        this.activity = null;
        Log.d(TAG,"onDetach method");
    }
}
