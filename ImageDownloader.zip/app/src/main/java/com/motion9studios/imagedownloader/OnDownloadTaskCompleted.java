package com.motion9studios.imagedownloader;

import android.net.Uri;

/**
 * Interface which allows DownloadAsyncTask to communicate with
 * the MainActivity
 */
public interface OnDownloadTaskCompleted extends OnTaskCompleted{


}
