package com.motion9studios.imagedownloader;

import android.net.Uri;

/**
 * Interface which allows AsyncTask to communicate with MainActivity
 */
public interface OnTaskCompleted {

    void onTaskCompleted(Uri uri);
    void onTaskCancelled(Uri uri);
}
