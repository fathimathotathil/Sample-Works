package com.motion9studios.imagedownloader;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.Toast;

/**
 * This Activity displays the screen's UI, creates a TaskFragment
 * to manage the task, and receives progress updates and results
 * from the TaskFragment when they occur.
 */
public class MainActivity extends LifecycleLoggingActivity {

    /**
     * Variable to identify retained fragment
     */
    private static final String TASK_FRAGMENT = "task_fragment";

    /**
     * TAG for Logging purposes
     */
    private final String TAG = getClass().getSimpleName();

    /**
     * Object of Retained fragment
     */

    TaskFragment taskFragment;

    /**
     * EditText field for entering the desired URL to an image.
     */
    private EditText urlEditText;

    /**
     * URL for the image
     */
    private Uri url ;

    /**
     * Object of Progress Dialog
     */

    private ProgressDialog progressDialog;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //If activity is created for the first time
        if (savedInstanceState == null) {

            taskFragment = new TaskFragment();
            getFragmentManager().beginTransaction().add(taskFragment, TASK_FRAGMENT).commit();
            Log.d(TAG, "Fragment created when activity is created for the first time");

        }
        //If activity is reloaded a subsequent time
        else {

            taskFragment = (TaskFragment) getFragmentManager().findFragmentByTag(TASK_FRAGMENT);
            Log.d(TAG, "Fragment retrieved when activity is reloaded a subsequent time");
        }

        //Initialize editText where user enters URL
        urlEditText = (EditText)findViewById(R.id.urlEditText);

    }


        /**
         * Called by the Android Activity framework when the user clicks
         * the "Download Image" button.
         *
         * @param view The view.
         */
        public void downloadImage(View view) {
            try {
                // Hide the keyboard.
                hideKeyboard(this,
                        urlEditText.getWindowToken());


                //Validate if the user has entered url or not
                if(!urlEditText.getText().toString().equals("")){

                    //If user entered URL, call getUrl private method
                    url = getUrl();
                }


                //If URL check completed successfully
                if(url!=null){

                    //Begin downloading the image and display progress dialog
                    progressDialog = ProgressDialog.show(this,"Wait","Downloading...");
                   taskFragment.beginDownloadTask(url, new OnDownloadTaskCompleted() {
                       @Override
                       // If image downloaded successfully
                       public void onTaskCompleted(Uri uri) {


                           // Begin filtering the image
                           taskFragment.beginFilterTask(uri,new OnFilterTaskCompleted() {
                               @Override
                               //If image filtered succesfully
                               public void onTaskCompleted(Uri filteredImageUri) {

                                   //Dismiss Progress Dialog
                                   progressDialog.dismiss();

                                   // Call the makeGalleryIntent() factory method to
                                   // create an Intent that will launch the "Gallery" app
                                   // by passing in the path to the downloaded image
                                   // file.

                                   Intent galleryIntent = makeGalleryIntent(filteredImageUri.toString());


                                   // Start the Gallery Activity.

                                   startActivity(galleryIntent);

                               }

                               // If image not filtered, then display Toast
                               @Override
                               public void onTaskCancelled(Uri uri) {


                                   //Dismiss Progress Dialog
                                   progressDialog.dismiss();
                                   Toast.makeText(getApplicationContext(),"Filtering interrupted...Try again.",Toast.LENGTH_SHORT).show();


                                   //Clear the editText so that user can enter another URL
                                   urlEditText.setText("");
                               }
                           });


                       }

                       //If image not downloaded, then display Toast
                       @Override
                       public void onTaskCancelled(Uri uri) {


                           //Dismiss Progress Dialog
                           progressDialog.dismiss();
                           Toast.makeText(getApplicationContext(),"Downloading interrupted...Try again.",Toast.LENGTH_SHORT).show();

                           //Clear the editText so that user can enter another URL
                           urlEditText.setText("");
                       }
                   });


                }

                else{

                    // if URL check failed in getURL() method
                    Toast.makeText(getApplicationContext(), "Enter a valid URL", Toast.LENGTH_SHORT).show();
                    urlEditText.setText("");
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    /**
     * This method is used to hide a keyboard after a user has
     * finished typing the url.
     */
    public void hideKeyboard(Activity activity,
                             IBinder windowToken) {
        InputMethodManager mgr =
                (InputMethodManager) activity.getSystemService
                        (Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(windowToken,
                0);
    }

    /**
     * Get the URL to download based on user input.
     */
    protected Uri getUrl() {
        Uri tempUrl = null;

        // Get the text the user typed in the edit text (if anything).
        tempUrl = Uri.parse(urlEditText.getText().toString());

        // If the user didn't provide a URL then use the default.
        String uri = tempUrl.toString();
        if (uri == null || uri.equals(""))
            tempUrl = url;

        // Do a sanity check to ensure the URL is valid, popping up a
        // toast if the URL is invalid.

        if (URLUtil.isValidUrl(uri))
            return tempUrl;
        else {
            Toast.makeText(this,
                    "Invalid URL",
                    Toast.LENGTH_SHORT).show();
            return null;
        }
    }


    /**
     * Factory method that returns an implicit Intent for viewing the
     * downloaded image in the Gallery app.
     */
    private Intent makeGalleryIntent(String pathToImageFile) {
        // Create an intent that will start the Gallery app to view
        // the image.

        Intent galleryIntent = new Intent(Intent.ACTION_VIEW);
        galleryIntent.setDataAndType(Uri.parse("file:"+pathToImageFile),"image/*");

        return galleryIntent;
    }



}




