package com.motion9studios.imagedownloader;

import android.net.Uri;

/**
 * Interface which allows FilterAsyncTask to communicate with MainActivity
 */
public interface OnFilterTaskCompleted extends OnTaskCompleted{

}

